"""Riwaq local assistant service."""
