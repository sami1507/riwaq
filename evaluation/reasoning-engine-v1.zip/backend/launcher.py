import os
import sys
from pathlib import Path

if getattr(sys, 'frozen', False):
    os.environ.setdefault('RIWAQ_DATA_DIR', str(Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Riwaq'))
    os.environ.setdefault('RIWAQ_STATIC_DIR', str(Path(sys._MEIPASS) / 'frontend' / 'dist'))

def main():
    import uvicorn
    uvicorn.run('backend.app:app',host='127.0.0.1',port=8765,log_level='info',access_log=False)

if __name__ == '__main__':
    main()
