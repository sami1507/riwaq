"""Explicit providers. No automatic fallback and no model-driven tool execution."""
import asyncio
import json
import httpx
import keyring

OLLAMA = 'http://127.0.0.1:11434'

def secret(provider):
    try:
        return keyring.get_password('Riwaq', provider)
    except Exception:
        return None

async def ollama_status():
    try:
        async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
            response = await client.get(OLLAMA + '/api/tags')
            response.raise_for_status()
            models = response.json().get('models', [])
            async def inspect(item):
                capable = False
                try:
                    detail = await client.post(OLLAMA + '/api/show', json={'model':item['name']})
                    detail.raise_for_status()
                    info = detail.json()
                    capable = 'completion' in info.get('capabilities', []) and not (info.get('remote_model') or info.get('remote_host'))
                except (httpx.HTTPError, ValueError, KeyError):
                    pass
                return item | {'chat_capable':bool(capable)}
            return {'available':True, 'models':await asyncio.gather(*(inspect(item) for item in models))}
    except (httpx.HTTPError, ValueError):
        return {'available':False,'models':[], 'reason':'Ollama is not reachable on 127.0.0.1:11434'}

async def validate_provider(provider, model, mode):
    if provider != 'ollama':
        if mode != 'hybrid':
            raise ValueError('Cloud providers are blocked in local-only mode.')
        if provider not in ('openai','anthropic'):
            raise ValueError('Unknown provider.')
        if not secret(provider):
            raise ValueError('Provider key is missing from the operating-system secret store.')
        return
    if any(x in model.lower() for x in (':cloud','-cloud','http:','https:','/')):
        raise ValueError('Only installed local Ollama models are allowed.')
    async with httpx.AsyncClient(timeout=5,trust_env=False) as client:
        r = await client.post(OLLAMA+'/api/show',json={'model':model})
        r.raise_for_status()
        info = r.json()
        if info.get('remote_model') or info.get('remote_host'):
            raise ValueError('Remote Ollama model is blocked. Use an explicitly configured cloud provider.')
        if 'completion' not in info.get('capabilities',[]):
            raise ValueError('Selected model does not support text chat.')

async def stream(provider,model,messages,config):
    timeout=httpx.Timeout(120,connect=8)
    async with httpx.AsyncClient(timeout=timeout,trust_env=False) as client:
        if provider=='ollama':
            payload={'model':model,'messages':messages,'stream':True,'think':False,'options':{'num_ctx':config['context_size'],'num_predict':config['max_tokens'],'temperature':config.get('temperature',0.3),**({'seed':config['seed']} if config.get('seed') is not None else {})},'keep_alive':'5m'}
            url=OLLAMA+'/api/chat'
            headers={}
        elif provider=='openai':
            url='https://api.openai.com/v1/responses'
            payload={'model':model,'input':messages,'stream':True,'store':False,'max_output_tokens':config['max_tokens']}
            headers={'Authorization':'Bearer '+secret(provider)}
        else:
            url='https://api.anthropic.com/v1/messages'
            payload={'model':model,'system':messages[0]['content'],'messages':messages[1:],'max_tokens':config['max_tokens'],'stream':True}
            headers={'x-api-key':secret(provider),'anthropic-version':'2023-06-01'}
        completed=False
        async with client.stream('POST',url,json=payload,headers=headers) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line:
                    continue
                if provider=='ollama':
                    obj=json.loads(line)
                    if obj.get('error'):
                        raise ValueError('Local model reported a generation error.')
                    delta=obj.get('message',{}).get('content','')
                    if delta:
                        yield {'content':delta}
                    if obj.get('done'):
                        completed=True
                        yield {'finish_reason':obj.get('done_reason', 'stop'), 'metrics':{k:obj[k] for k in ('eval_count','eval_duration','total_duration','load_duration','prompt_eval_count') if k in obj}}
                elif line.startswith('data: '):
                    if line[6:]=='[DONE]':
                        completed=True
                        continue
                    obj=json.loads(line[6:])
                    typ=obj.get('type','')
                    if typ=='response.output_text.delta':
                        yield {'content':obj.get('delta','')}
                    elif typ=='content_block_delta' and obj.get('delta',{}).get('type')=='text_delta':
                        yield {'content':obj['delta']['text']}
                    elif typ == 'message_delta' and obj.get('delta', {}).get('stop_reason'):
                        yield {'finish_reason':obj['delta']['stop_reason']}
                    elif typ in ('response.completed','message_stop'):
                        completed=True
                    elif typ == 'response.incomplete':
                        completed=True
                        yield {'finish_reason':obj.get('response', {}).get('incomplete_details', {}).get('reason', 'incomplete')}
                    elif typ in ('error','response.failed'):
                        raise ValueError('Cloud provider could not complete the response.')
        if not completed:
            raise ValueError('Provider stream ended before its completion event.')
