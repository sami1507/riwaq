"""Opt-in encrypted sync gateway; OS keyring holds account session tokens."""
import json
import os
import re
from urllib.parse import urlparse
import httpx
import keyring
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from backend.db import settings

router=APIRouter(prefix='/api/sync')
BUSY=set()

def endpoint():
    value=os.environ.get('RIWAQ_SYNC_URL','http://127.0.0.1:8766').rstrip('/')
    u=urlparse(value)
    local=u.hostname in ('127.0.0.1','localhost')
    if u.username or u.password or u.query or u.fragment or u.path not in ('','/') or not (u.scheme=='https' or (local and u.scheme=='http')):
        raise HTTPException(503,'Sync endpoint must be HTTPS, or loopback HTTP for local tests, without credentials or a path.')
    return value

def token():
    try: return keyring.get_password('RiwaqSync',endpoint())
    except Exception: return None

@router.get('/status')
def status():
    return {'endpoint':endpoint(),'configured':True,'authenticated':bool(token()),'mode':settings()['mode'],'automatic':False}

async def proxy(method,path,payload=None,auth=True):
    if settings()['mode']!='hybrid': raise HTTPException(403,'Sync is blocked in local-only mode.')
    headers={}
    if auth:
        credential=token()
        if not credential: raise HTTPException(401,'Sign in to the configured sync server first.')
        headers['Authorization']='Bearer '+credential
    marker=object();BUSY.add(marker)
    try:
        async with httpx.AsyncClient(timeout=20,trust_env=False,follow_redirects=False) as client:
            async with client.stream(method,endpoint()+path,json=payload,headers=headers) as r:
                parts=[];size=0
                async for part in r.aiter_bytes():
                    size+=len(part)
                    if size>6*1024*1024: raise HTTPException(502,'Sync response exceeds limit.')
                    parts.append(part)
                try: result=json.loads(b''.join(parts)) if parts else {'ok':True}
                except ValueError: raise HTTPException(502,'Invalid sync response')
                if r.status_code>=300:
                    raise HTTPException(r.status_code if 400<=r.status_code<500 else 502,'Sync request rejected by server (HTTP '+str(r.status_code)+').')
                return result
    except httpx.HTTPError:
        raise HTTPException(503,'Configured sync service is unavailable. No data was substituted.')
    finally: BUSY.discard(marker)

class Login(BaseModel):
    email:str=Field(min_length=3,max_length=254)
    password:str=Field(min_length=12,max_length=128)

async def authenticate(kind,body):
    result=await proxy('POST','/auth/'+kind,body.model_dump(),auth=False)
    try: keyring.set_password('RiwaqSync',endpoint(),result['token'])
    except Exception: raise HTTPException(503,'Secure OS token storage failed. Sync is not signed in.')
    return {'authenticated':True,'email':body.email}

@router.post('/register')
async def register(body:Login): return await authenticate('register',body)

@router.post('/login')
async def login(body:Login): return await authenticate('login',body)

@router.post('/logout')
async def logout():
    remote_revoked=False
    try:
        if token() and settings()['mode']=='hybrid':
            await proxy('POST','/auth/logout')
            remote_revoked=True
    except HTTPException: pass
    finally:
        try: keyring.delete_password('RiwaqSync',endpoint())
        except keyring.errors.PasswordDeleteError: pass
        except Exception: raise HTTPException(503,'Could not clear the OS session token.')
    return {'signed_out':True,'remote_revoked':remote_revoked}

@router.get('/snapshots')
async def list_snapshots(): return await proxy('GET','/snapshots')

def safe_id(id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',id): raise HTTPException(400,'Invalid snapshot ID')
    return id

@router.get('/snapshots/{id}')
async def get_snapshot(id:str): return await proxy('GET','/snapshots/'+safe_id(id))

@router.put('/snapshots/{id}')
async def put_snapshot(id:str,request:Request):
    body=await request.body()
    if len(body)>4*1024*1024: raise HTTPException(413,'Encrypted snapshot exceeds 4 MB')
    return await proxy('PUT','/snapshots/'+safe_id(id),await request.json())
