import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def data_dir():
    path = Path(os.environ.get('RIWAQ_DATA_DIR', str(ROOT / 'data')))
    path.mkdir(parents=True, exist_ok=True)
    return path

def now():
    return datetime.now(timezone.utc).isoformat()

def uid():
    return uuid.uuid4().hex

@contextmanager
def get_db():
    conn = sqlite3.connect(data_dir() / 'riwaq.sqlite3', timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA busy_timeout=10000')
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()

def event(conn, project_id, kind, summary):
    conn.execute('INSERT INTO events VALUES (?,?,?,?,?)', (uid(), project_id, kind, summary, now()))

def init_db():
    with get_db() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,name TEXT NOT NULL,instructions TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),title TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,parent_id TEXT);
        CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,role TEXT NOT NULL,content TEXT NOT NULL,status TEXT NOT NULL,model TEXT,created_at TEXT NOT NULL,citations TEXT NOT NULL DEFAULT '[]');
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),kind TEXT NOT NULL,summary TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS memories(id TEXT PRIMARY KEY,scope TEXT NOT NULL,project_id TEXT REFERENCES projects(id),content TEXT NOT NULL,created_at TEXT NOT NULL);
        ''')
        c.execute("UPDATE messages SET status='interrupted' WHERE status='streaming'")
        if not c.execute('SELECT 1 FROM projects LIMIT 1').fetchone():
            pid = uid()
            c.execute('INSERT INTO projects VALUES (?,?,?,?)',(pid,'مساحتي الأولى','',now()))
            event(c,pid,'created','تم إنشاء مساحة العمل المحلية')
        from backend.reasoning import init_reasoning
        init_reasoning(c)
        from backend.knowledge import init_knowledge
        init_knowledge(c)
        from backend.studio import init_studio
        init_studio(c)
        from backend.public_knowledge import init_public_knowledge
        init_public_knowledge(c)

DEFAULTS = {'mode':'local','provider':'ollama','model':'qwen3:4b-instruct','max_tokens':1024,'context_size':8192}

def settings():
    with get_db() as c:
        return DEFAULTS | {r['key']:json.loads(r['value']) for r in c.execute('SELECT * FROM settings')}

def message_dict(row):
    result = dict(row)
    result['citations'] = json.loads(result.get('citations','[]'))
    from backend.reasoning import read_receipt
    with get_db() as conn:
        receipt=read_receipt(conn,result['id'])
    if receipt is not None: result['run']=receipt
    return result
