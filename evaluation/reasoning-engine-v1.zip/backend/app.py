import asyncio
import json
import os
import re
import time
from contextlib import asynccontextmanager, aclosing
from pathlib import Path
from typing import Literal

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, StreamingResponse
from pydantic import BaseModel, Field
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from backend.db import get_db, init_db, uid, now, event, settings, message_dict
from backend import providers, knowledge, public_knowledge, workspace, sync_client, snapshots, media, grounding, reasoning

ACTIVE = {}
ALLOWED_ORIGINS = {'http://127.0.0.1:8765','http://localhost:8765','http://127.0.0.1:5173','http://localhost:5173','http://tauri.localhost','https://tauri.localhost','tauri://localhost'}

@asynccontextmanager
async def lifespan(app):
    init_db()
    with get_db() as c:
        workspace.init_workspace(c)
    yield
    for task in list(ACTIVE.values()):
        task['stop'].set()
    await public_knowledge.shutdown_public_knowledge()

app=FastAPI(title='Riwaq local service',version='0.1.0',lifespan=lifespan,docs_url='/api/docs')

@app.exception_handler(RequestValidationError)
async def validation_error(request,exc):
    return JSONResponse({'detail':[{'loc':e['loc'],'msg':e['msg'],'type':e['type']} for e in exc.errors()]},422)
app.add_middleware(CORSMiddleware,allow_origins=list(ALLOWED_ORIGINS),allow_methods=['GET','POST','PATCH','DELETE','OPTIONS'],allow_headers=['Content-Type','X-Riwaq-Client'])
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['127.0.0.1','localhost','testserver','tauri.localhost'])

class RequestGuard:
    """Reject cross-origin requests and bound bodies before multipart parsing."""
    def __init__(self,app): self.app=app
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':
            return await self.app(scope,receive,send)
        headers={k.decode().lower():v.decode() for k,v in scope.get('headers',[])}
        if scope['path'].startswith('/api') and scope['method']!='OPTIONS':
            origin=headers.get('origin')
            if (origin and origin not in ALLOWED_ORIGINS) or headers.get('x-riwaq-client')!='local' or headers.get('sec-fetch-site')=='cross-site':
                return await JSONResponse({'detail':'Local client header and trusted origin required.'},403)(scope,receive,send)
        limit=9*1024*1024
        body=[]
        size=0
        while True:
            msg=await receive()
            if msg['type']=='http.disconnect': return
            size+=len(msg.get('body',b''))
            if size>limit:
                return await JSONResponse({'detail':'Request exceeds 9 MB.'},413)(scope,receive,send)
            body.append(msg)
            if not msg.get('more_body',False): break
        async def replay():
            if body: return body.pop(0)
            return await receive()
        async def secured_send(message):
            if message['type']=='http.response.start':
                response_headers=list(message.get('headers',[]))
                response_headers.append((b'x-frame-options',b'DENY'))
                response_headers.append((b'x-content-type-options',b'nosniff'))
                response_headers.append((b'referrer-policy',b'no-referrer'))
                if not any(k.lower()==b'content-security-policy' for k,v in response_headers):
                    response_headers.append((b'content-security-policy',b"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' http://127.0.0.1:8765; object-src 'none'; frame-ancestors 'none'"))
                message['headers']=response_headers
            await send(message)
        await self.app(scope,replay,secured_send)

app.add_middleware(RequestGuard)
app.include_router(knowledge.router)
from backend import studio
app.include_router(studio.router)
app.include_router(public_knowledge.router)
app.include_router(workspace.router)
app.include_router(sync_client.router)
app.include_router(snapshots.router)
app.include_router(media.router)

class ProjectInput(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    instructions:str=Field(default='',max_length=12000)

class ProjectPatch(BaseModel):
    name:str|None=Field(default=None,min_length=1,max_length=120)
    instructions:str|None=Field(default=None,max_length=12000)

class ConversationInput(BaseModel):
    project_id:str
    title:str=Field(default='محادثة جديدة',max_length=120)

class GenerateInput(BaseModel):
    content:str=Field(default='',max_length=20000)
    model:str|None=Field(default=None,max_length=100)
    provider:Literal['ollama','openai','anthropic']|None=None
    retry_message_id:str|None=None
    edit_message_id:str|None=None
    use_files:bool=False
    use_knowledge:bool=False
    depth:Literal['auto','quick','analytical','research']|None=None
    calculation:reasoning.Calculation|None=None
    hypothesis:reasoning.Hypothesis|None=None
    review:bool=False

class SettingsPatch(BaseModel):
    mode:Literal['local','hybrid']|None=None
    provider:Literal['ollama','openai','anthropic']|None=None
    model:str|None=Field(default=None,min_length=1,max_length=100)
    max_tokens:int|None=Field(default=None,ge=32,le=4096)
    context_size:int|None=Field(default=None,ge=2048,le=16384)
    temperature:float|None=Field(default=None,ge=0,le=1)
    seed:int|None=Field(default=None,ge=0,le=2147483647)

def require(c,table,id):
    assert table in ('projects','conversations','messages','memories')
    row=c.execute(f'SELECT * FROM {table} WHERE id=?',(id,)).fetchone()
    if not row: raise HTTPException(404,'Not found')
    return row

@app.get('/api/status')
async def status():
    cfg=settings()
    local=await providers.ollama_status()
    media_info=await media.media_status()
    return {'version':'0.1.0',**cfg,'ollama':local,'capabilities':{
        'vision':media_info['vision'],
        'stt':media_info['stt'],
        'tts':media_info['tts'],
        'web_search':{'available':cfg['mode']=='hybrid' and bool(providers.secret('brave')),'reason':'Requires hybrid mode and Brave API key in OS keyring.'},
        'code_execution':{'available':False,'reason':'No verified OS sandbox; preview, diff and explicit apply only.'},
        'sync':{'available':cfg['mode']=='hybrid','reason':'Manual encrypted project backup; requires a configured account server and explicit sign-in.'}
    },'providers':{name:{'configured':bool(providers.secret(name)),'tested':False} for name in ('openai','anthropic')}}

@app.get('/api/settings')
def get_settings(): return settings()

@app.patch('/api/settings')
async def update_settings(body:SettingsPatch):
    values=body.model_dump(exclude_none=True)
    if ACTIVE or sync_client.BUSY or public_knowledge.BUSY: raise HTTPException(409,'Stop generation, knowledge imports, or sync before changing privacy settings.')
    merged=settings()|values
    if merged['context_size'] - merged['max_tokens'] < 768:
        raise HTTPException(422, 'Context must leave at least 768 tokens beyond the output limit.')
    if merged['mode']=='local': values['provider']='ollama'
    with get_db() as c:
        for k,v in values.items():
            c.execute('INSERT OR REPLACE INTO settings VALUES (?,?)',(k,json.dumps(v)))
    return settings()

@app.get('/api/projects')
def projects():
    with get_db() as c: return [dict(x) for x in c.execute('SELECT * FROM projects ORDER BY created_at')]

@app.post('/api/projects')
def add_project(body:ProjectInput):
    with get_db() as c:
        id=uid(); c.execute('INSERT INTO projects VALUES (?,?,?,?)',(id,body.name,body.instructions,now()))
        event(c,id,'created','Project created: '+body.name)
        return dict(require(c,'projects',id))

@app.get('/api/projects/{id}')
def project(id:str):
    with get_db() as c: return dict(require(c,'projects',id))

@app.patch('/api/projects/{id}')
def update_project(id:str,body:ProjectPatch):
    with get_db() as c:
        require(c,'projects',id)
        for k,v in body.model_dump(exclude_none=True).items():
            c.execute(f'UPDATE projects SET {k}=? WHERE id=?',(v,id))
        event(c,id,'instructions_updated','Project name or instructions updated by user')
        return dict(require(c,'projects',id))

@app.get('/api/conversations')
def conversations(project_id:str|None=None,q:str=''):
    with get_db() as c:
        return [dict(r) for r in c.execute('''SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id=c.id
        WHERE (? IS NULL OR c.project_id=?) AND (c.title LIKE ? OR m.content LIKE ?) ORDER BY c.updated_at DESC LIMIT 200''',(project_id,project_id,'%'+q+'%','%'+q+'%'))]

@app.post('/api/conversations')
def add_conversation(body:ConversationInput):
    with get_db() as c:
        require(c,'projects',body.project_id)
        id=uid(); stamp=now()
        c.execute('INSERT INTO conversations VALUES (?,?,?,?,?,?)',(id,body.project_id,body.title,stamp,stamp,None))
        event(c,body.project_id,'conversation_created',body.title)
        return dict(require(c,'conversations',id))

@app.get('/api/conversations/{id}')
def conversation(id:str):
    with get_db() as c:
        return dict(require(c,'conversations',id))|{'messages':[message_dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY rowid',(id,))]}

@app.delete('/api/conversations/{id}')
async def delete_conversation(id:str):
    if id in ACTIVE: raise HTTPException(409,'Stop generation first')
    with get_db() as c:
        row=require(c,'conversations',id)
        c.execute('DELETE FROM conversations WHERE id=?',(id,))
        event(c,row['project_id'],'conversation_deleted','Conversation deleted by user')
    return {'deleted':True}

@app.get('/api/conversations/{id}/export')
def export(id:str,format:Literal['markdown','json']='markdown'):
    data=conversation(id)
    if format=='json': return JSONResponse(data,headers={'Content-Disposition':'attachment; filename="riwaq-conversation.json"'})
    content='# '+data['title']+'\n\n'+'\n\n'.join('## '+m['role']+'\n\n'+m['content'] for m in data['messages'])
    return PlainTextResponse(content,headers={'Content-Disposition':'attachment; filename="riwaq-conversation.md"'})

def encode(obj): return (json.dumps(obj,ensure_ascii=False)+'\n').encode()

class ManagedStreamingResponse(StreamingResponse):
    def __init__(self,*args,finalizer,**kwargs):
        super().__init__(*args,**kwargs);self.finalizer=finalizer
    async def __call__(self,scope,receive,send):
        try:return await super().__call__(scope,receive,send)
        finally:await self.finalizer()

async def prepare_wait(awaitable,job,request):
    remaining=job['deadline']-time.monotonic()
    if remaining<=0:
        if hasattr(awaitable,'close'):awaitable.close()
        raise HTTPException(504,'Task preparation reached its time budget')
    return await media.await_work(asyncio.create_task(awaitable),job,request,remaining)

@app.post('/api/conversations/{id}/generate')
async def generate(id:str,body:GenerateInput,request:Request):
    if ACTIVE: raise HTTPException(409,'One generation can run at a time on this device.')
    with get_db() as c:require(c,'conversations',id)
    job={'stop':asyncio.Event(),'deadline':time.monotonic()+180,'started':time.monotonic()}
    ACTIVE[id]=job
    try:
        return await generate_prepared(id,body,request,job)
    except BaseException:
        for key,value in list(ACTIVE.items()):
            if value is job:ACTIVE.pop(key,None)
        raise

async def generate_prepared(id,body,request,job):
    cfg=settings(); provider=body.provider or cfg['provider']; model=body.model or cfg['model']
    task_run=None
    with get_db() as c:
        prior=[dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY rowid',(id,))]
    lookup=body.content
    if body.retry_message_id:
        at=next((i for i,m in enumerate(prior) if m['id']==body.retry_message_id),None)
        if at is None:raise HTTPException(404,'Branch message not in this conversation')
        lookup=next((m['content'] for m in reversed(prior[:at]) if m['role']=='user'),'')
    if body.depth is not None or body.calculation or body.hypothesis:
        if provider!='ollama':raise HTTPException(400,'Paid reasoning is disabled until an explicit priced budget is configured. Select the local provider.')
        task_run=reasoning.Run(uid(),body.depth or 'auto',lookup,body.calculation,body.hypothesis,body.review)
        task_run.started=job['started'];job['deadline']=job['started']+task_run.data['ceilings']['wall_seconds']
    if not body.content.strip() and not body.retry_message_id: raise HTTPException(422,'Message is empty')
    public_chunks=[]
    if body.use_knowledge:
        # Read before awaiting retrieval; never keep a SQLite write transaction open
        # across model I/O. Recheck settings/concurrency before saving any messages.
        with get_db() as c:
            require(c,'conversations',id)
            prior=[dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY rowid',(id,))]
        lookup=body.content
        if body.retry_message_id:
            at=next((i for i,m in enumerate(prior) if m['id']==body.retry_message_id),None)
            if at is None: raise HTTPException(404,'Branch message not in this conversation')
            lookup=next((m['content'] for m in reversed(prior[:at]) if m['role']=='user'),'')
        if task_run:task_run.tool()
        public_chunks=await prepare_wait(public_knowledge.retrieve_public(lookup,limit=5),job,request)
        if task_run:task_run.stage('retrieve','complete')
        if settings()!=cfg: raise HTTPException(409,'Privacy or model settings changed while preparing. Please send again.')
    try:
        await prepare_wait(providers.validate_provider(provider,model,cfg['mode']),job,request)
    except ValueError as e: raise HTTPException(400,str(e))
    except httpx.HTTPError: raise HTTPException(503,'Local model unavailable. Start Ollama and install the selected model.')
    if settings()!=cfg: raise HTTPException(409,'Privacy or model settings changed while preparing. Please send again.')
    if job['stop'].is_set() or await request.is_disconnected():raise HTTPException(499,'Preparation cancelled')
    with get_db() as c:
        if public_chunks:
            current = public_knowledge.authorize_current(c, public_chunks)
            if len(current) != len(public_chunks):
                raise HTTPException(409, 'Knowledge rights or versions changed while preparing. Please send again.')
            public_chunks = current
        conv=require(c,'conversations',id)
        proj=require(c,'projects',conv['project_id'])
        history=[dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY rowid',(id,))]
        if body.edit_message_id or body.retry_message_id:
            target=body.edit_message_id or body.retry_message_id
            index=next((i for i,m in enumerate(history) if m['id']==target),None)
            if index is None: raise HTTPException(404,'Branch message not in this conversation')
            expected='user' if body.edit_message_id else 'assistant'
            if history[index]['role']!=expected: raise HTTPException(400,'Invalid branch target role')
            old=id; id=uid(); stamp=now()
            c.execute('INSERT INTO conversations VALUES (?,?,?,?,?,?)',(id,conv['project_id'],conv['title']+' · فرع',stamp,stamp,old))
            history=history[:index]
            for m in history:
                copied_id=uid()
                c.execute('INSERT INTO messages VALUES (?,?,?,?,?,?,?,?)',(copied_id,id,m['role'],m['content'],m['status'],m['model'],m['created_at'],m['citations']))
                previous_run=reasoning.read_receipt(c,m['id'])
                if previous_run:reasoning.save_receipt(c,copied_id,previous_run)
            event(c,conv['project_id'],'branch_created','Conversation branched; original preserved')
        if not body.retry_message_id:
            c.execute('INSERT INTO messages VALUES (?,?,?,?,?,?,?,?)',(uid(),id,'user',body.content,'complete',None,now(),'[]'))
            history.append({'role':'user','content':body.content,'status':'complete'})
        question=next((m['content'] for m in reversed(history) if m['role']=='user'),'')
        if task_run and body.use_files:task_run.tool()
        chunks=knowledge.retrieve(c,conv['project_id'],question) if body.use_files else []
        if task_run and body.use_files:task_run.stage('retrieve','complete')
        # Different retrieval scores are not comparable. Alternate the two explicitly
        # selected knowledge scopes and cap source text before constructing context.
        candidates=[]
        for index in range(max(len(chunks),len(public_chunks))):
            if index<len(chunks): candidates.append(chunks[index])
            if index<len(public_chunks): candidates.append(public_chunks[index])
        chunks=[]; source_chars=0
        for candidate in candidates:
            size=len(candidate['text'])
            if source_chars+size>12000: continue
            chunks.append(candidate); source_chars+=size
            if len(chunks)==6: break
        memories=[dict(x) for x in c.execute("SELECT * FROM memories WHERE scope='preference' OR project_id=? ORDER BY created_at LIMIT 30",(conv['project_id'],))]
        try:
            messages, chunks = grounding.compose(proj, memories, history, question, chunks, cfg, body.use_files or body.use_knowledge, system_extra=task_run.instructions() if task_run else '')
        except ValueError as exc:
            raise HTTPException(413, str(exc)) from exc
        public_chunks = [chunk for chunk in chunks if chunk.get('scope') == 'public']
        mid=uid()
        c.execute('INSERT INTO messages VALUES (?,?,?,?,?,?,?,?)',(mid,id,'assistant','','streaming',model,now(),json.dumps(chunks,ensure_ascii=False)))
        c.execute('UPDATE conversations SET updated_at=?,title=CASE WHEN title=? THEN ? ELSE title END WHERE id=?',(now(),'محادثة جديدة',question[:70],id))
    for key,value in list(ACTIVE.items()):
        if value is job and key!=id:ACTIVE.pop(key,None)
    stop=job['stop']; ACTIVE[id]=job
    if task_run:
        with get_db() as c:reasoning.save_receipt(c,mid,task_run.data)
    async def run():
        nonlocal messages, chunks, public_chunks
        content=''; state='complete'; metrics={}; error=None; iterator=None
        try:
            revoked = False
            if public_chunks:
                with get_db() as c:
                    if len(public_knowledge.authorize_current(c, public_chunks)) != len(public_chunks):
                        chunks.clear()
                        c.execute("UPDATE messages SET citations='[]' WHERE id=?", (mid,))
                        revoked = True
            yield encode({'type':'start','conversation_id':id,'message_id':mid,'citations':chunks,**({'run':task_run.data} if task_run else {})})
            if revoked:
                raise ValueError('Knowledge rights or versions changed before generation. Please send again.')
            if (body.use_files or body.use_knowledge) and not chunks:
                content='لم أجد مقاطع ذات صلة في المصادر المختارة. أضف مصدرًا مناسبًا أو عدّل السؤال. / No relevant source excerpts were found in the selected knowledge sources.'
                yield encode({'type':'delta','content':content})
            else:
                if public_chunks:
                    with get_db() as c:
                        if len(public_knowledge.authorize_current(c, public_chunks)) != len(public_chunks):
                            raise ValueError('Knowledge rights or versions changed before model dispatch. Please send again.')
                async def produce():
                    nonlocal messages,chunks,public_chunks
                    async def authorize_dispatch():
                        if stop.is_set():raise asyncio.CancelledError()
                        with get_db() as c:
                            if public_chunks and len(public_knowledge.authorize_current(c,public_chunks))!=len(public_chunks):raise ValueError('Knowledge rights changed before dispatch')
                            for chunk in chunks:
                                if chunk.get('scope')!='public' and not c.execute('SELECT 1 FROM knowledge_chunks ch JOIN knowledge_files f ON f.id=ch.file_id WHERE ch.id=? AND ch.project_id=? AND f.project_id=?',(chunk['id'],conv['project_id'],conv['project_id'])).fetchone():raise ValueError('Private source removed before dispatch')
                    if task_run:
                        tool_context=''
                        async for preparation in task_run.prepare_events():
                            if 'tool_context' in preparation:tool_context=preparation['tool_context']
                            else:yield preparation
                        if tool_context:
                            messages,chunks=grounding.compose(proj,memories,history,question,chunks,cfg,body.use_files or body.use_knowledge,system_extra=task_run.instructions(),tool_context=tool_context)
                            public_chunks=[chunk for chunk in chunks if chunk.get('scope')=='public']
                            with get_db() as c:c.execute('UPDATE messages SET citations=? WHERE id=?',(json.dumps(chunks,ensure_ascii=False),mid))
                            yield {'type':'citations','citations':chunks}
                        async with aclosing(task_run.stream(provider,model,messages,cfg,chunks,before_dispatch=authorize_dispatch)) as output:
                            async for packet in output:yield packet
                    else:
                        await authorize_dispatch()
                        async with aclosing(providers.stream(provider,model,messages,cfg)) as output:
                            async for packet in output:yield packet
                iterator=produce().__aiter__()
                async with asyncio.timeout(max(.001,job['deadline']-time.monotonic())):
                    while True:
                        if stop.is_set(): state='cancelled'; break
                        next_chunk=asyncio.create_task(anext(iterator))
                        cancelled=asyncio.create_task(stop.wait())
                        try:
                            done,_=await asyncio.wait([next_chunk,cancelled],return_when=asyncio.FIRST_COMPLETED)
                            if cancelled in done:
                                state='cancelled'; break
                            try: packet=next_chunk.result()
                            except StopAsyncIteration: break
                            if packet.get('type'):
                                if task_run:
                                    with get_db() as c:reasoning.save_receipt(c,mid,task_run.data)
                                yield encode(packet)
                                continue
                            if 'replacement' in packet:
                                if len(packet['replacement'])>100000:raise ValueError('Replacement exceeded output limit')
                                content=packet['replacement']
                                with get_db() as c:c.execute('UPDATE messages SET content=? WHERE id=?',(content,mid))
                                yield encode({'type':'replace','content':content})
                                continue
                            delta=packet.get('content','')
                            metrics.update(packet.get('metrics',{}))
                            reason = packet.get('finish_reason')
                            if reason:
                                metrics['finish_reason'] = reason
                                if reason not in {'stop', 'end_turn', 'stop_sequence', 'completed'}:
                                    state = 'interrupted'
                                    error = 'الرد غير مكتمل؛ انتهى التوليد قبل اكتماله. / Response incomplete; generation ended before completion.'
                            if delta:
                                content+=delta
                                with get_db() as c: c.execute('UPDATE messages SET content=? WHERE id=?',(content,mid))
                                yield encode({'type':'delta','content':delta})
                            if len(content)>100000: raise ValueError('Response exceeded output limit.')
                        finally:
                            for task in (next_chunk,cancelled):
                                if not task.done(): task.cancel()
                            await asyncio.gather(next_chunk,cancelled,return_exceptions=True)
                await iterator.aclose()
                if state == 'complete' and not content.strip():
                    state = 'error'
                    error = 'لم يُرجع النموذج نصًا. / The model returned no answer text.'
        except (asyncio.CancelledError,GeneratorExit):
            state='cancelled'
            raise
        except (Exception,TimeoutError) as exc:
            state='interrupted' if isinstance(exc,(reasoning.BudgetExceeded,TimeoutError)) else 'error'
            error=str(exc) if isinstance(exc,ValueError) else 'Generation interrupted by provider failure or time limit. Partial text was saved.'
        finally:
            try:
                if iterator is not None:
                    try:await iterator.aclose()
                    except Exception:
                        state='error';error='Provider cleanup failed; partial text was preserved.'
                # Invalid citation markers cannot become source links. Supported sources remain separate from claims.
                invalid=[n for n in reasoning.citation_markers(content) if not reasoning.valid_marker(n,len(chunks))]
                if invalid:
                    content=re.sub(r'\[S(\d+)\]',lambda m:m.group() if reasoning.valid_marker(m[1],len(chunks)) else '[unverified citation]',content)
                    error='Model returned an unsupported citation; it was flagged.'
                with get_db() as c:
                    c.execute('UPDATE messages SET content=?,status=? WHERE id=?',(content,state,mid))
                    if task_run:
                        task_run.stage('save','complete');reasoning.save_receipt(c,mid,task_run.finish(state))
                    event(c,conv['project_id'],'response_'+state,f'{provider}/{model}: {state}')
            finally:
                for key,value in list(ACTIVE.items()):
                    if value is job:ACTIVE.pop(key,None)
        with get_db() as c: saved=message_dict(require(c,'messages',mid))
        if error: yield encode({'type':'error','message':error})
        yield encode({'type':'done','message':saved,'metrics':metrics})
    output=run()
    async def finalize_response():
        try:
            await output.aclose()
        finally:
            try:
                with get_db() as c:
                    row=c.execute('SELECT status FROM messages WHERE id=?',(mid,)).fetchone()
                    if row and row['status']=='streaming':
                        c.execute("UPDATE messages SET status='cancelled' WHERE id=?",(mid,))
                        if task_run:reasoning.save_receipt(c,mid,task_run.finish('cancelled'))
            finally:
                for key,value in list(ACTIVE.items()):
                    if value is job:ACTIVE.pop(key,None)
    return ManagedStreamingResponse(output,finalizer=finalize_response,media_type='application/x-ndjson',headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

@app.post('/api/conversations/{id}/stop')
async def stop(id:str):
    active=id in ACTIVE
    if active: ACTIVE[id]['stop'].set()
    return {'stopped':active}

class MemoryInput(BaseModel):
    content:str=Field(min_length=1,max_length=2000)
    scope:Literal['preference','project']='preference'
    project_id:str|None=None

@app.get('/api/memories')
def memories(project_id:str|None=None):
    with get_db() as c:
        return [dict(x) for x in c.execute("SELECT * FROM memories WHERE scope='preference' OR project_id=? ORDER BY created_at",(project_id,))]

@app.post('/api/memories')
def add_memory(body:MemoryInput):
    with get_db() as c:
        if body.scope=='project': require(c,'projects',body.project_id)
        id=uid()
        c.execute('INSERT INTO memories VALUES (?,?,?,?,?)',(id,body.scope,body.project_id if body.scope=='project' else None,body.content,now()))
        return dict(require(c,'memories',id))

@app.patch('/api/memories/{id}')
def edit_memory(id:str,body:MemoryInput):
    with get_db() as c:
        require(c,'memories',id)
        if body.scope=='project': require(c,'projects',body.project_id)
        c.execute('UPDATE memories SET content=?,scope=?,project_id=? WHERE id=?',(body.content,body.scope,body.project_id if body.scope=='project' else None,id))
        return dict(require(c,'memories',id))

@app.delete('/api/memories/{id}')
def delete_memory(id:str):
    with get_db() as c:
        require(c,'memories',id); c.execute('DELETE FROM memories WHERE id=?',(id,))
    return {'deleted':True}

class EventInput(BaseModel):
    kind:Literal['goal','decision','completed','blocker','next_step']
    summary:str=Field(min_length=1,max_length=2000)

@app.post('/api/projects/{id}/events')
def add_event(id:str,body:EventInput):
    with get_db() as c:
        require(c,'projects',id); event(c,id,body.kind,body.summary)
    return {'recorded':True}

@app.get('/api/projects/{id}/events')
def events(id:str):
    with get_db() as c:
        require(c,'projects',id)
        return [dict(x) for x in c.execute('SELECT * FROM events WHERE project_id=? ORDER BY created_at DESC LIMIT 200',(id,))]

@app.get('/api/projects/{id}/state')
def state(id:str):
    log=events(id)
    with get_db() as c:
        decisions=[json.loads(row['payload']) | {'id':row['id'],'version':row['version']} for row in c.execute("SELECT * FROM studio_entries WHERE project_id=? AND kind='decision' ORDER BY updated_at DESC",(id,))]
    def latest(kind,default=''): return next((e['summary'] for e in log if e['kind']==kind),default)
    current=[{'id':d['id'],'summary':d['title']+' — '+d['decision'],'status':d['status'],'version':d['version'],'source':'decision-notebook'} for d in decisions if d['status'] in {'adopted','implemented'}]
    completed=[{'id':d['id'],'summary':d['title']+' — '+d['implementation_evidence'],'status':'implemented','verification':'user-attestation','source':'decision-notebook'} for d in decisions if d['status']=='implemented']
    return {'goal':latest('goal'),'decisions':current+[e for e in log if e['kind']=='decision'],'completed':completed+[e for e in log if e['kind']=='completed'],'blockers':[e for e in log if e['kind']=='blocker'],'next_step':latest('next_step'),'events':log[:20],'source':'event-log+current-decisions','updated_at':log[0]['created_at'] if log else None}

@app.get('/api/search/web')
async def web_search(q:str):
    if settings()['mode']!='hybrid': raise HTTPException(403,'Internet search is blocked in local-only mode.')
    key=providers.secret('brave')
    if not key: raise HTTPException(503,'No search provider configured; no results available.')
    marker=object(); sync_client.BUSY.add(marker)
    try:
        async with httpx.AsyncClient(timeout=15,trust_env=False) as client:
            r=await client.get('https://api.search.brave.com/res/v1/web/search',params={'q':q[:500],'count':5},headers={'X-Subscription-Token':key})
            r.raise_for_status()
            return {'retrieved_at':now(),'results':[{'title':x['title'],'url':x['url'],'description':x.get('description',''),'published_at':x.get('age')} for x in r.json().get('web',{}).get('results',[])]}
    except httpx.HTTPError: raise HTTPException(502,'Search provider failed; no synthetic results returned.')
    finally: sync_client.BUSY.discard(marker)

STATIC=Path(os.environ.get('RIWAQ_STATIC_DIR',Path(__file__).resolve().parent.parent/'frontend'/'dist'))

@app.get('/{path:path}')
def spa(path:str):
    if path.startswith('api/'): raise HTTPException(404,'Unknown API endpoint')
    target=(STATIC/path).resolve()
    if target.is_relative_to(STATIC.resolve()) and target.is_file(): return FileResponse(target)
    index=STATIC/'index.html'
    if index.exists(): return FileResponse(index,headers={'Cache-Control':'no-cache','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' http://127.0.0.1:8765; object-src 'none'; frame-ancestors 'none'"})
    return JSONResponse({'name':'Riwaq','detail':'Build frontend with npm --prefix frontend run build.'},503)
